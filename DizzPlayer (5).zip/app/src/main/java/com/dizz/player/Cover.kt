package com.dizz.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.min
import kotlin.math.roundToInt

object Look {
    var cover by mutableStateOf<ImageBitmap?>(null)
    var accent by mutableStateOf(Color(0xFF9B5CFF))
}

/** Общие часы кадров: визуализация и слой обложки перерисовываются от них. */
object Clock {
    var t by mutableLongStateOf(0L)
}

fun coverOn() = Cfg.showCover && Look.cover != null

/** Центр визуализации: если есть обложка — немного выше середины, чтобы обложка легла в кольцо. */
fun vizCenter(w: Float, h: Float) = if (coverOn()) Offset(w / 2f, h * 0.40f) else Offset(w / 2f, h / 2f)

fun hueShift(c: Color, d: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    return Color.hsv((((hsv[0] + d) % 360f) + 360f) % 360f, hsv[1].coerceAtLeast(0.5f), hsv[2].coerceAtLeast(0.9f))
}

object Covers {
    private val DEF = Color(0xFF9B5CFF)

    fun request(t: Track?) {
        if (t == null) { Look.cover = null; Look.accent = DEF; return }
        Look.cover = null
        Thread {
            val bmp = try { load(Engine.app, t) } catch (e: Exception) { null }
            if (App.current?.id == t.id) {
                Look.cover = bmp?.asImageBitmap()
                Look.accent = if (bmp != null) accent(bmp) else DEF
            }
        }.start()
    }

    private fun decode(b: ByteArray): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / s > 1024 || o.outHeight / s > 1024) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeByteArray(b, 0, b.size, o2)
    }

    fun load(ctx: Context, t: Track): Bitmap? {
        try {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, t.uri)
                val pic = r.embeddedPicture
                if (pic != null) { val d = decode(pic); if (d != null) return d }
            } finally { r.release() }
        } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT >= 29) {
            try { return ctx.contentResolver.loadThumbnail(t.uri, android.util.Size(800, 800), null) } catch (e: Exception) { }
        }
        return null
    }

    /** Самый насыщенный и яркий оттенок обложки — для акцентного цвета интерфейса. */
    fun accent(b: Bitmap): Color {
        val s = Bitmap.createScaledBitmap(b, 24, 24, true)
        val hsv = FloatArray(3)
        var best = 0f; var bh = -1f
        for (y in 0 until 24) for (x in 0 until 24) {
            android.graphics.Color.colorToHSV(s.getPixel(x, y), hsv)
            val sc = hsv[1] * hsv[2]
            if (hsv[2] > 0.35f && sc > best) { best = sc; bh = hsv[0] }
        }
        return if (bh < 0f || best < 0.15f) DEF else Color.hsv(bh, 0.65f, 1f)
    }
}

/** Обложка рисуется ПОВЕРХ визуализации и вспышки. */
@Composable
fun CoverLayer() {
    val img = Look.cover
    if (!Cfg.showCover || img == null) return
    Canvas(Modifier.fillMaxSize()) {
        val tick = Clock.t
        if (tick == Long.MIN_VALUE) return@Canvas
        val w = size.width; val h = size.height
        val c = vizCenter(w, h)
        val pulse = Engine.pulse
        val d = min(w, h) * Cfg.coverSize * (1f + 0.05f * pulse)
        val side = min(img.width, img.height)
        val ox = (img.width - side) / 2; val oy = (img.height - side) / 2
        val tl = Offset(c.x - d / 2f, c.y - d / 2f)
        drawCircle(Look.accent.copy(alpha = 0.18f + 0.25f * pulse), d * 0.62f, c, blendMode = BlendMode.Plus)
        val path = Path()
        if (Cfg.coverShape == 0) path.addOval(Rect(tl, Size(d, d)))
        else path.addRoundRect(RoundRect(Rect(tl, Size(d, d)), CornerRadius(d * 0.12f)))
        clipPath(path) {
            drawImage(
                img, IntOffset(ox, oy), IntSize(side, side),
                IntOffset(tl.x.roundToInt(), tl.y.roundToInt()), IntSize(d.roundToInt(), d.roundToInt())
            )
        }
        drawPath(path, Color.White.copy(alpha = 0.25f), style = Stroke(2f))
    }
}
