package com.dizz.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.zip.ZipInputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/* ===== Поддержка шаблонов Avee Player (.viz = ZIP: scene.json + картинки) ===== */

class Info(val posMs: Long = 0L, val durMs: Long = 0L, val title: String = "", val artist: String = "")

/** Элемент сцены: обёртка над JSON. Параметры хранятся как {"v": значение, "t": тип, ...}. */
class El(val o: JSONObject) {
    val type: String = o.optString("objType")
    private val c = HashMap<String, Any?>()
    fun has(k: String) = o.has(k)
    fun raw(k: String): Any? {
        if (c.containsKey(k)) return c[k]
        val x = o.opt(k)
        val v = if (x is JSONObject) x.opt("v") else x
        c[k] = v
        return v
    }
    fun nested(k: String): JSONObject? = o.optJSONObject(k)
    fun f(k: String, d: Float = 0f): Float = when (val v = raw(k)) {
        is Number -> v.toFloat()
        is String -> v.toFloatOrNull() ?: d
        else -> d
    }
    fun b(k: String, d: Boolean = false): Boolean = when (val v = raw(k)) {
        is Number -> v.toInt() != 0
        is Boolean -> v
        else -> d
    }
    fun s(k: String, d: String = ""): String = raw(k)?.toString() ?: d
    fun f2(k: String, dx: Float = 0f, dy: Float = 0f): Pair<Float, Float> {
        val p = s(k).trim().split(" ")
        return Pair(p.getOrNull(0)?.toFloatOrNull() ?: dx, p.getOrNull(1)?.toFloatOrNull() ?: dy)
    }
    fun col(k: String, d: Int = -1): Int = (raw(k) as? Number)?.toInt() ?: d
    fun hsla(k: String, d: Int = -1): Int {
        val p = s(k).trim().split(" ").mapNotNull { it.toFloatOrNull() }
        return if (p.size < 4) d else hslToArgb(p[0], p[1], p[2], p[3])
    }
    /** Значения "mvarf": "Constant a b", "Beat a b" (a в покое → b на бите) и т.п. */
    fun mv(k: String, def: Float): Float {
        val p = s(k).trim().split(" ")
        val a = p.getOrNull(1)?.toFloatOrNull() ?: def
        val b = p.getOrNull(2)?.toFloatOrNull() ?: a
        return when (p.getOrNull(0)) {
            "Constant", "TrackPosition", "TotalTime", "BeatRandomShake" -> a
            "Beat" -> a + (b - a) * Engine.pulse.coerceIn(0f, 1f)
            else -> def
        }
    }
}

private fun nv(o: JSONObject?, k: String): Any? {
    val x = o?.opt(k)
    return if (x is JSONObject) x.opt("v") else x
}
private fun nf(o: JSONObject?, k: String, d: Float): Float = (nv(o, k) as? Number)?.toFloat() ?: d
private fun ni(o: JSONObject?, k: String, d: Int): Int = (nv(o, k) as? Number)?.toInt() ?: d

fun hslToArgb(h: Float, s: Float, l: Float, a: Float): Int {
    val hh = ((h % 1f) + 1f) % 1f
    val q = if (l < 0.5f) l * (1f + s) else l + s - l * s
    val p = 2f * l - q
    fun hue(t0: Float): Float {
        var t = t0
        if (t < 0f) t += 1f
        if (t > 1f) t -= 1f
        return when {
            t < 1f / 6f -> p + (q - p) * 6f * t
            t < 0.5f -> q
            t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
            else -> p
        }
    }
    fun ch(x: Float) = (x * 255f).roundToInt().coerceIn(0, 255)
    return Color.argb(ch(a), ch(hue(hh + 1f / 3f)), ch(hue(hh)), ch(hue(hh - 1f / 3f)))
}

private fun lerpArgb(a: Int, b: Int, u: Float): Int {
    fun m(x: Int, y: Int) = (x + (y - x) * u).roundToInt().coerceIn(0, 255)
    return Color.argb(m(Color.alpha(a), Color.alpha(b)), m(Color.red(a), Color.red(b)), m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b)))
}

private fun mulArgb(a: Int, b: Int): Int =
    Color.argb(Color.alpha(a) * Color.alpha(b) / 255, Color.red(a) * Color.red(b) / 255, Color.green(a) * Color.green(b) / 255, Color.blue(a) * Color.blue(b) / 255)

/** Умножает каналы картинки на цвет (окраска), не закрашивая прозрачные места. */
private fun modulate(c: Int): ColorMatrixColorFilter = ColorMatrixColorFilter(
    ColorMatrix(
        floatArrayOf(
            Color.red(c) / 255f, 0f, 0f, 0f, 0f,
            0f, Color.green(c) / 255f, 0f, 0f, 0f,
            0f, 0f, Color.blue(c) / 255f, 0f, 0f,
            0f, 0f, 0f, Color.alpha(c) / 255f, 0f
        )
    )
)

private fun xfer(mode: String): PorterDuffXfermode? = when (mode) {
    "Add", "AddAlpha" -> PorterDuffXfermode(PorterDuff.Mode.ADD)
    "Screen" -> PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    else -> null
}

private fun bp(mode: String, alpha: Float = 1f, tint: Int = -1): Paint {
    val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    p.xfermode = xfer(mode)
    p.alpha = (alpha * 255f).toInt().coerceIn(0, 255)
    if (tint != -1) p.colorFilter = modulate(tint)
    return p
}

private fun fmtTime(ms: Long): String {
    val s = max(0L, ms) / 1000
    return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}

private fun solid(c: Int): Bitmap {
    val b = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888)
    b.eraseColor(c)
    return b
}

private fun radial(size: Int, f: (Float) -> Float): Bitmap {
    val px = IntArray(size * size)
    val c = (size - 1) / 2f
    for (y in 0 until size) for (x in 0 until size) {
        val d = hypot(x - c, y - c) / c
        px[y * size + x] = Color.argb((f(d).coerceIn(0f, 1f) * 255f).toInt(), 255, 255, 255)
    }
    val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    b.setPixels(px, 0, size, 0, 0, size, size)
    return b
}

/** Встроенные ресурсы Avee ("internalres:...") рисуем сами. */
private fun internalRes(name: String): Bitmap = when {
    name == "white" -> solid(Color.WHITE)
    name == "black" -> solid(Color.BLACK)
    name == "transparent" -> solid(Color.TRANSPARENT)
    name.contains("vignette") || name.contains("inv") -> radial(128) { d -> ((d - 0.45f) / 0.65f).pow(1.5f) }
    name.contains("rainbow") -> {
        val b = Bitmap.createBitmap(128, 8, Bitmap.Config.ARGB_8888)
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, 128f, 0f, IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }, null, Shader.TileMode.CLAMP)
        Canvas(b).drawRect(0f, 0f, 128f, 8f, p)
        b
    }
    name.contains("sharp") || name.contains("w_a") -> radial(128) { d -> if (d < 0.85f) 1f else (1f - d) / 0.15f }
    else -> radial(128) { d -> (1f - d).pow(1.7f) }
}

class Prov(val e: El) {
    val out = FloatArray(max(2, min(512, e.f("sampleOutCount", 64f).toInt())))
}

private class Pt(var x: Float, var y: Float, var vx: Float, var vy: Float, var age: Float, val life: Float, val size: Float)
private class PS { val l = ArrayList<Pt>(); var acc = 0f; var last = 0L }
private class Acc(var a: Bitmap, var b: Bitmap)

class AveeScene(private val dir: File) {
    private val comps: List<List<El>>
    private val provs = ArrayList<Prov>()
    private var W = 0
    private var H = 0
    private var frame = 0
    private var info = Info()
    private val done = HashMap<Int, Int>()
    private val layers = HashMap<Int, Bitmap>()
    private val local = HashMap<String, Bitmap?>()
    private val internalBmps = HashMap<String, Bitmap>()
    private val blurBufs = HashMap<El, Array<Bitmap>>()
    private val accs = HashMap<El, Acc>()
    private val ps = HashMap<El, PS>()
    private val fonts = HashMap<String, Typeface?>()
    private var scratch: Bitmap? = null
    private val filt = Paint(Paint.FILTER_BITMAP_FLAG)
    private var lastBeat = -1
    private var shake = 0f

    init {
        val root = JSONObject(File(dir, "scene.json").readText())
        val arr = root.getJSONArray("compositions")
        val list = ArrayList<List<El>>()
        for (i in 0 until arr.length()) {
            val els = arr.getJSONObject(i).optJSONArray("elements")
            val l = ArrayList<El>()
            if (els != null) for (j in 0 until els.length()) l.add(El(els.getJSONObject(j)))
            list.add(l)
        }
        comps = list
        for (e in comps.getOrElse(0) { emptyList() }) if (e.type == "AudioProvider") provs.add(Prov(e))
        if (provs.isEmpty()) for (c in comps) for (e in c) if (e.type == "AudioProvider") provs.add(Prov(e))
    }

    private fun reset() {
        layers.clear(); done.clear(); blurBufs.clear(); accs.clear(); ps.clear(); scratch = null
    }

    /** Рисует кадр шаблона и возвращает битмап композиции 0. */
    fun render(w: Int, h: Int, q: Float, inf: Info): Bitmap? {
        val rw = (w * q).toInt().coerceAtLeast(64)
        val rh = (h * q).toInt().coerceAtLeast(64)
        if (rw != W || rh != H) { W = rw; H = rh; reset() }
        info = inf
        frame++
        for (p in provs) updateProv(p)
        if (Engine.beatCount != lastBeat) { lastBeat = Engine.beatCount; shake = Random.nextFloat() * 6.2832f }
        return renderComp(0, HashSet())
    }

    private fun updateProv(p: Prov) {
        val e = p.e
        val n = p.out.size
        val lo = max(e.f("lowerHz", 20f), 20f)
        val hi = max(e.f("higherHz", 5000f), lo + 1f)
        val lin = e.f("hzLinearFactor", 1f).coerceIn(0f, 1f)
        val mult = e.f("outputMultiplier", 1f)
        val mirror = e.b("mirrorSamples")
        val rel = 0.25f / (1f + e.f("smooth", 0.5f))
        for (k in 0 until n) {
            var fr = if (n > 1) k.toFloat() / (n - 1) else 0f
            if (mirror) fr = abs(2f * fr - 1f)
            val flin = lo + (hi - lo) * fr
            val flog = lo * (hi / lo).pow(fr)
            val tgt = (Engine.magAt(flog + (flin - flog) * lin) * mult).coerceIn(0f, 4f)
            val cur = p.out[k]
            p.out[k] = if (tgt > cur) cur + (tgt - cur) * 0.6f else cur + (tgt - cur) * rel
        }
    }

    private fun renderComp(i: Int, stack: HashSet<Int>): Bitmap? {
        if (i !in comps.indices) return null
        if (done[i] == frame) return layers[i]
        val existing = layers[i]
        if (!stack.add(i)) return existing
        val bmp = existing ?: Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { layers[i] = it }
        bmp.eraseColor(Color.TRANSPARENT)
        val cv = Canvas(bmp)
        for (e in comps[i]) {
            try { drawEl(cv, e, stack) } catch (ex: Exception) { }
        }
        stack.remove(i)
        done[i] = frame
        return bmp
    }

    private fun decode(f: File): Bitmap? {
        if (!f.exists()) return null
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1280 || o.outHeight / s > 1280) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeFile(f.path, o2)
    }

    private fun bitmapFor(name: String, stack: HashSet<Int>): Bitmap? {
        if (name.isEmpty()) return null
        if (name.startsWith("composition:")) return renderComp(name.substring(12).toIntOrNull() ?: return null, stack)
        if (name.startsWith("internalres:")) return internalBmps.getOrPut(name) { internalRes(name.substring(12)) }
        if (name.startsWith("local:")) {
            if (local.containsKey(name)) return local[name]
            val b = try { decode(File(dir, name.substring(6))) } catch (e: Exception) { null }
            local[name] = b
            return b
        }
        return null
    }

    private fun drawEl(cv: Canvas, e: El, stack: HashSet<Int>) {
        if (e.has("visible") && !e.b("visible", true)) return
        when (e.type) {
            "Image" -> image(cv, e, stack)
            "Bars" -> bars(cv, e)
            "Particles" -> particles(cv, e, stack)
            "Text" -> text(cv, e)
            "BlurEffect" -> blur(cv, e, stack)
            "MotionBlurEffect" -> motion(cv, e, stack)
            "RgbSplitEffect" -> rgb(cv, e, stack)
            "MirrorEffect" -> mirror(cv, e, stack)
            "FOV" -> fov(cv, e, stack)
        }
    }

    // ---------- Image ----------

    private fun tintPaint(e: El): Paint {
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val t = e.hsla("Color")
        if (t != -1) p.colorFilter = modulate(t)
        return p
    }

    private fun image(cv: Canvas, e: El, stack: HashSet<Int>) {
        val bmp = bitmapFor(e.s("customImage"), stack) ?: return
        val maskName = e.s("MaskImage")
        val mask = if (maskName.isNotEmpty()) bitmapFor(maskName, stack) else null
        val alpha = e.f("opacityStrength", 1f).coerceIn(0f, 1f)
        if (mask == null) {
            placeBitmap(cv, e, bmp, bp(e.s("blendMode"), alpha, e.hsla("Color")))
            return
        }
        val sc = scratch ?: Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { scratch = it }
        sc.eraseColor(Color.TRANSPARENT)
        val scv = Canvas(sc)
        placeBitmap(scv, e, bmp, tintPaint(e))
        val mp = Paint(Paint.FILTER_BITMAP_FLAG)
        mp.xfermode = PorterDuffXfermode(if (e.s("maskMode").startsWith("Inverted")) PorterDuff.Mode.DST_OUT else PorterDuff.Mode.DST_IN)
        scv.drawBitmap(mask, null, Rect(0, 0, W, H), mp)
        cv.drawBitmap(sc, 0f, 0f, bp(e.s("blendMode"), alpha))
    }

    /** Положение: pos/scale — доли экрана; keepAspectRatio вписывает картинку в прямоугольник (sx*W, sy*H). */
    private fun placeBitmap(cv: Canvas, e: El, bmp: Bitmap, paint: Paint) {
        val (px, py) = e.f2("position", 0.5f, 0.5f)
        val (sx, sy) = e.f2("scale", 1f, 1f)
        val (ax, ay) = e.f2("alignmentPosition", 0.5f, 0.5f)
        val bw = abs(sx) * W
        val bh = abs(sy) * H
        if (bw < 1f || bh < 1f) return
        val ar = bmp.width.toFloat() / bmp.height
        val crop = e.b("keepAspectRatioAndCropToFit")
        val keep = e.b("keepAspectRatio", true)
        var dw = bw
        var dh = bh
        if (crop) { if (bw / bh > ar) dh = bw / ar else dw = bh * ar }
        else if (keep) { if (bw / bh > ar) dw = bh * ar else dh = bw / ar }
        val cx = px * W
        val cy = py * H
        val bl = cx - ax * bw
        val bt = cy - ay * bh
        val l = bl + (bw - dw) / 2f
        val t = bt + (bh - dh) / 2f
        cv.save()
        val rot = e.f("rotation")
        if (rot != 0f) cv.rotate(rot, cx, cy)
        if (crop) cv.clipRect(bl, bt, bl + bw, bt + bh)
        if (e.s("Shape") == "Circle") {
            val p = Path()
            p.addOval(RectF(l, t, l + dw, t + dh), Path.Direction.CW)
            cv.clipPath(p)
        }
        cv.drawBitmap(bmp, null, RectF(l, t, l + dw, t + dh), paint)
        cv.restore()
    }

    // ---------- Bars ----------

    private fun bars(cv: Canvas, e: El) {
        val idx = e.f("audioProviderIndex", 1f).toInt() - 1
        val pr = provs.getOrNull(idx) ?: provs.firstOrNull() ?: return
        val v = pr.out
        val n = v.size
        val (px, py) = e.f2("position", 0.5f, 0.5f)
        val (sx, sy) = e.f2("scale", 1f, 1f)
        val hs = e.f("heightScale", 1f)
        val minH = e.f("minHeightScale", 0f)
        val circle = e.s("ShapePath") == "Circle"
        val boxW = abs(sx) * W
        val boxH = abs(sy) * H
        val cx = px * W
        val cy = py * H
        val r = nf(e.nested("ShapePath"), "radius", 1f) * min(boxW, boxH) / 2f
        val flip = e.b("flipInput")
        cv.save()
        cv.rotate(e.f("rotation"), cx, cy)
        for (sn in arrayOf("Segment1", "Segment2")) {
            val type = e.s(sn)
            if (type.isEmpty() || type == "None") continue
            val so = e.nested(sn)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.xfermode = xfer(e.s("blendMode"))
            paint.color = ni(so, "colorFrom", -1)
            paint.style = Paint.Style.STROKE
            val bhm = nf(so, "barHeightMultiplier", 1f)
            val bwid = nf(so, "barWidth", 1f)
            val fixed = nf(so, "fixedHeight", 0f)
            val mirror = ni(so, "mirror", 0) != 0
            val arc = if (circle) 2f * PI.toFloat() * r / n else boxW / n
            val unit = if (circle) r else boxH * 0.2f
            if (type == "Line") {
                paint.strokeWidth = max(2f, W / 300f)
                paint.strokeJoin = Paint.Join.ROUND
            } else {
                paint.strokeWidth = max(1f, arc * bwid * 0.8f)
                paint.strokeCap = if (type == "RoundBars") Paint.Cap.ROUND else Paint.Cap.BUTT
            }
            val path = Path()
            val path2 = Path()
            for (i in 0 until n) {
                val vi = v[if (flip) n - 1 - i else i]
                val len = (max(vi * hs * bhm, minH) + fixed * 0.01f) * unit
                val x0: Float
                val y0: Float
                val x1: Float
                val y1: Float
                val x2: Float
                val y2: Float
                if (circle) {
                    val a = -PI.toFloat() / 2f + 2f * PI.toFloat() * i / n
                    val ca = cos(a)
                    val sa = sin(a)
                    x0 = cx + ca * (r - if (mirror) len else 0f); y0 = cy + sa * (r - if (mirror) len else 0f)
                    x1 = cx + ca * (r + len); y1 = cy + sa * (r + len)
                    x2 = cx + ca * (r - len); y2 = cy + sa * (r - len)
                } else {
                    val x = cx - boxW / 2f + boxW * (i + 0.5f) / n
                    x0 = x; y0 = cy + if (mirror) len else 0f
                    x1 = x; y1 = cy - len
                    x2 = x; y2 = cy + len
                }
                if (type == "Line") {
                    if (i == 0) { path.moveTo(x1, y1); path2.moveTo(x2, y2) } else { path.lineTo(x1, y1); path2.lineTo(x2, y2) }
                } else cv.drawLine(x0, y0, x1, y1, paint)
            }
            if (type == "Line") {
                if (circle) { path.close(); path2.close() }
                cv.drawPath(path, paint)
                if (mirror) cv.drawPath(path2, paint)
            }
        }
        cv.restore()
    }

    // ---------- Particles ----------

    private fun particles(cv: Canvas, e: El, stack: HashSet<Int>) {
        val spr = bitmapFor(e.s("customImage"), stack) ?: return
        val st = ps.getOrPut(e) { PS() }
        val now = System.nanoTime()
        val dt = if (st.last == 0L) 0f else ((now - st.last) / 1e9f).coerceAtMost(0.05f)
        st.last = now
        val k = W / 1080f
        val (px, py) = e.f2("position", 0.5f, 0.5f)
        val (sx, sy) = e.f2("scale", 1f, 1f)
        val limit = min(e.f("CountLimit", 400f).toInt(), 350)
        val every = max(e.f("spawnTime", 0.02f), 0.004f)
        val life = max(e.f("lifetime", 2f), 0.1f)
        val area = e.s("SpawnArea")
        val sa = e.nested("SpawnArea")
        st.acc += dt
        var guard = 0
        while (st.acc >= every && guard < 40) {
            st.acc -= every
            guard++
            if (st.l.size >= limit) continue
            val x = px * W + (Random.nextFloat() - 0.5f) * sx * W
            val y = if (area == "HorizontalLine") py * H else py * H + (Random.nextFloat() - 0.5f) * sy * H
            val ang = if (ni(sa, "useRandomVectorInstead", 0) != 0) Random.nextFloat() * 6.2832f
            else Math.toRadians(nf(sa, "vectorAngle", 90f).toDouble()).toFloat()
            val spd = (e.f("Speed") + (Random.nextFloat() * 2f - 1f) * e.f("speedRandom")) * k
            val sz = (e.f("endSize") + Random.nextFloat() * e.f("endSizeRandom")) * e.f("particleScale", 1f) * 0.1f * k
            st.l.add(Pt(x, y, cos(ang) * spd, -sin(ang) * spd, 0f, life * (0.7f + Random.nextFloat() * 0.3f), max(2f, sz)))
        }
        val (gx, gy) = e.f2("gravity")
        val c0 = e.hsla("ColorFrom")
        val c1 = e.hsla("ColorTo")
        val mul = e.col("color")
        val fade = max(e.f("fadeInAndOutTime", 0.1f), 0.01f)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        paint.xfermode = xfer(e.s("blendMode"))
        val iter = st.l.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            p.age += dt
            if (p.age >= p.life) { iter.remove(); continue }
            p.vx += gx * k * dt
            p.vy += gy * k * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            val u = p.age / p.life
            val a = min(1f, min(u / fade, (1f - u) / fade))
            paint.colorFilter = modulate(mulArgb(lerpArgb(c0, c1, u), mul))
            paint.alpha = (a * 255f).toInt().coerceIn(0, 255)
            val s = p.size * (0.3f + 0.7f * min(1f, u * 5f))
            cv.drawBitmap(spr, null, RectF(p.x - s / 2f, p.y - s / 2f, p.x + s / 2f, p.y + s / 2f), paint)
        }
    }

    // ---------- Text ----------

    private fun text(cv: Canvas, e: El) {
        val i = info
        val s = e.s("text").replace("{TimeCurrent}", fmtTime(i.posMs)).replace("{TimeLength}", fmtTime(i.durMs))
            .replace("{TrackName}", i.title).replace("{TrackTitle}", i.title)
            .replace("{ArtistName}", i.artist).replace("{Artist}", i.artist)
        if (s.isBlank()) return
        val (px, py) = e.f2("position", 0.5f, 0.5f)
        val (sx, _) = e.f2("scale", 1f, 1f)
        val (ax, _) = e.f2("alignmentPosition", 0.5f, 0.5f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = e.col("color")
        p.textSize = max(6f, e.f("fontSize", 40f) * abs(sx) * W / 1080f)
        p.xfermode = xfer(e.s("blendMode"))
        p.textAlign = if (ax < 0.25f) Paint.Align.LEFT else if (ax > 0.75f) Paint.Align.RIGHT else Paint.Align.CENTER
        val tf = e.s("typeFace")
        if (tf.isNotEmpty() && !tf.startsWith("internal")) {
            if (!fonts.containsKey(tf)) fonts[tf] = try { Typeface.createFromFile(File(dir, tf)) } catch (ex: Exception) { null }
            fonts[tf]?.let { p.typeface = it }
        }
        cv.drawText(s, px * W, py * H + p.textSize * 0.35f, p)
    }

    // ---------- Эффекты ----------

    private fun blurred(e: El, src: Bitmap, steps: Int): Bitmap {
        val bufs = blurBufs.getOrPut(e) {
            Array(steps) { i -> Bitmap.createBitmap(max(8, W shr (i + 1)), max(8, H shr (i + 1)), Bitmap.Config.ARGB_8888) }
        }
        var prev = src
        for (b in bufs) {
            b.eraseColor(Color.TRANSPARENT)
            Canvas(b).drawBitmap(prev, null, Rect(0, 0, b.width, b.height), filt)
            prev = b
        }
        return prev
    }

    private fun blur(cv: Canvas, e: El, stack: HashSet<Int>) {
        val src = renderComp(e.f("sourceCompositionIndex").toInt(), stack) ?: return
        val bm = e.s("blendModeContent", "Add")
        if (e.b("showUnblurredContentUnder") || e.b("showUnblurredContent")) cv.drawBitmap(src, 0f, 0f, bp(bm))
        val small = blurred(e, src, if (e.f("blurMultiplier", 2f) < 1.5f) 2 else 3)
        for (k in 1..3) {
            val (lx, ly) = e.f2("${k}layerScale", 1f, 1f)
            if (lx <= 0.01f || ly <= 0.01f) continue
            cv.save()
            cv.scale(lx, ly, W / 2f, H / 2f)
            cv.drawBitmap(small, null, Rect(0, 0, W, H), bp(bm, 1f, e.col("${k}layerColor")))
            cv.restore()
        }
    }

    private fun motion(cv: Canvas, e: El, stack: HashSet<Int>) {
        val src = bitmapFor(e.s("TargetImage"), stack) ?: return
        val ac = accs.getOrPut(e) {
            Acc(Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888), Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888))
        }
        val (sx, sy) = e.f2("scale", 1f, 1f)
        ac.b.eraseColor(Color.TRANSPARENT)
        val c = Canvas(ac.b)
        c.save()
        c.scale(sx, sy, W / 2f, H / 2f)
        val trail = Paint(Paint.FILTER_BITMAP_FLAG)
        trail.alpha = (0.78f * 255f).toInt()
        c.drawBitmap(ac.a, 0f, 0f, trail)
        c.restore()
        c.drawBitmap(src, 0f, 0f, filt)
        val t = ac.a
        ac.a = ac.b
        ac.b = t
        cv.drawBitmap(ac.a, 0f, 0f, null)
    }

    private fun rgb(cv: Canvas, e: El, stack: HashSet<Int>) {
        val name = e.s("targetImage").ifEmpty { e.s("TargetImage") }
        val src = bitmapFor(name, stack) ?: return
        val d = abs(e.mv("splitAmount", 0f)) * W * e.mv("splitMultiplier", 1f).coerceIn(0f, 12f)
        val ox = cos(shake) * d
        val oy = sin(shake) * d
        val cols = intArrayOf(e.col("splitColor0"), e.col("splitColor1"), e.col("splitColor2"))
        for (i in 0..2) {
            val s = (i - 1).toFloat()
            cv.drawBitmap(src, s * ox, s * oy, bp("Add", 1f, cols[i]))
        }
    }

    private fun mirror(cv: Canvas, e: El, stack: HashSet<Int>) {
        val src = bitmapFor(e.s("TargetImage"), stack) ?: return
        val mode = e.s("mirrorMode", "Horizontal")
        val flip = e.b("flipMirror")
        val hor = mode.contains("Horizontal")
        val ver = mode.contains("Vertical")
        val hx = W / 2f
        val hy = H / 2f
        val xs = if (hor) intArrayOf(1, -1) else intArrayOf(1)
        val ys = if (ver) intArrayOf(1, -1) else intArrayOf(1)
        for (fx in xs) for (fy in ys) {
            cv.save()
            val left = if (!hor) 0f else if ((fx == 1) != flip) 0f else hx
            val right = if (!hor) W.toFloat() else if ((fx == 1) != flip) hx else W.toFloat()
            val top = if (!ver) 0f else if ((fy == 1) != flip) 0f else hy
            val bottom = if (!ver) H.toFloat() else if ((fy == 1) != flip) hy else H.toFloat()
            cv.clipRect(left, top, right, bottom)
            cv.scale(if (fx == -1) -1f else 1f, if (fy == -1) -1f else 1f, hx, hy)
            cv.drawBitmap(src, 0f, 0f, filt)
            cv.restore()
        }
    }

    private fun fov(cv: Canvas, e: El, stack: HashSet<Int>) {
        val src = bitmapFor(e.s("TargetImage"), stack) ?: return
        cv.drawBitmap(src, null, Rect(0, 0, W, H), filt)
    }
}

/** Рендерит шаблон в отдельном потоке (~30 к/с), чтобы интерфейс не тормозил. */
class Runner(private val dir: File) {
    @Volatile private var running = false
    @Volatile var failed = false
    @Volatile var info = Info()
    @Volatile var wantW = 0
    @Volatile var wantH = 0
    @Volatile var q = 0.4f
    private val lock = Any()
    private var front: Bitmap? = null
    private var scene: AveeScene? = null
    private val blit = Paint(Paint.FILTER_BITMAP_FLAG)

    fun start() {
        if (running) return
        running = true
        val t = Thread { loop() }
        t.isDaemon = true
        t.start()
    }

    fun stop() { running = false }

    private fun loop() {
        if (scene == null) {
            try { scene = AveeScene(dir) } catch (e: Throwable) { failed = true; running = false; return }
        }
        val sc = scene ?: return
        while (running) {
            val w = wantW
            val h = wantH
            if (w < 16 || h < 16) { Thread.sleep(30); continue }
            val t0 = System.nanoTime()
            try {
                val bmp = sc.render(w, h, q, info)
                if (bmp != null) {
                    synchronized(lock) {
                        var f = front
                        if (f == null || f.width != bmp.width || f.height != bmp.height) {
                            f = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                            front = f
                        }
                        f.eraseColor(Color.TRANSPARENT)
                        Canvas(f).drawBitmap(bmp, 0f, 0f, null)
                    }
                }
            } catch (e: Throwable) {
                try { Thread.sleep(200) } catch (x: Exception) { }
            }
            val ms = (System.nanoTime() - t0) / 1_000_000
            if (ms < 33) { try { Thread.sleep(33 - ms) } catch (x: Exception) { } }
        }
    }

    /** true — кадр нарисован. */
    fun draw(cv: Canvas, w: Int, h: Int): Boolean {
        var ok = false
        synchronized(lock) {
            val f = front
            if (f != null) {
                cv.drawBitmap(f, null, Rect(0, 0, w, h), blit)
                ok = true
            }
        }
        return ok
    }
}

object Templates {
    val names = mutableStateListOf<String>()
    private val runners = HashMap<String, Runner>()

    private fun root(c: Context) = File(c.filesDir, "viz")

    fun refresh(c: Context) {
        val l = root(c).listFiles { f -> f.isDirectory && File(f, "scene.json").exists() }
            ?.map { it.name }?.sorted() ?: emptyList()
        names.clear()
        names.addAll(l)
    }

    fun runner(c: Context, name: String): Runner = runners.getOrPut(name) { Runner(File(root(c), name)) }

    /** Распаковывает .viz (ZIP) в приватную папку приложения. Возвращает имя шаблона. */
    fun import(c: Context, uri: Uri): String {
        var disp = "template"
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) disp = it.getString(0) ?: disp
        }
        val base = disp.substringBeforeLast('.').replace(Regex("[^\\p{L}\\p{N}_\\- ]"), "_").trim().ifEmpty { "template" }
        var name = base
        var n = 2
        while (File(root(c), name).exists()) { name = "$base ($n)"; n++ }
        val dir = File(root(c), name)
        dir.mkdirs()
        val canon = dir.canonicalPath + File.separator
        try {
            ZipInputStream(c.contentResolver.openInputStream(uri) ?: throw Exception("Не удалось открыть файл")).use { z ->
                var en = z.nextEntry
                while (en != null) {
                    if (!en.isDirectory) {
                        val out = File(dir, en.name)
                        if (!out.canonicalPath.startsWith(canon)) throw Exception("Некорректный архив")
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o -> z.copyTo(o) }
                    }
                    z.closeEntry()
                    en = z.nextEntry
                }
            }
            if (!File(dir, "scene.json").exists()) throw Exception("В файле нет scene.json — это не шаблон Avee")
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
        return name
    }

    fun delete(c: Context, name: String) {
        runners.remove(name)?.stop()
        File(root(c), name).deleteRecursively()
        refresh(c)
    }
}
