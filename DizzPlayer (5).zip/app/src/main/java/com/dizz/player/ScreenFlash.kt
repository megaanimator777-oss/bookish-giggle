package com.dizz.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

val FLASH_COLORS = listOf(
    "Белый" to Color(0xFFFFFFFF),
    "Красный" to Color(0xFFFF1744),
    "Оранжевый" to Color(0xFFFF9100),
    "Жёлтый" to Color(0xFFFFEA00),
    "Зелёный" to Color(0xFF00E676),
    "Голубой" to Color(0xFF00E5FF),
    "Синий" to Color(0xFF2979FF),
    "Фиолетовый" to Color(0xFFD500F9),
    "Розовый" to Color(0xFFFF4081)
)

object ScreenFlash {
    var level by mutableFloatStateOf(0f)
    @Volatile var ticks = 0

    fun pulse() { ticks++; level = 1f }

    /** 0..8 — готовые цвета, 9 — свой оттенок, 10 — радуга (новый цвет на каждый удар). */
    fun color(): Color = when {
        Cfg.screenColor < FLASH_COLORS.size -> FLASH_COLORS[Cfg.screenColor].second
        Cfg.screenColor == FLASH_COLORS.size -> Color.hsv(Cfg.screenHue.coerceIn(0f, 360f), 1f, 1f)
        else -> Color.hsv(((ticks * 47) % 360).toFloat(), 1f, 1f)
    }
}

/** Полноэкранная вспышка поверх всего приложения. Касания не перехватывает. */
@Composable
fun ScreenFlashOverlay() {
    val active by remember { derivedStateOf { ScreenFlash.level > 0f } }
    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        var last = 0L
        while (ScreenFlash.level > 0f) {
            withFrameNanos { n ->
                val dt = if (last == 0L) 0f else (n - last) / 1_000_000f
                last = n
                ScreenFlash.level = (ScreenFlash.level - dt / Cfg.screenLen.coerceAtLeast(30f)).coerceAtLeast(0f)
            }
        }
    }
    Canvas(Modifier.fillMaxSize()) {
        val l = ScreenFlash.level
        if (l > 0f) drawRect(ScreenFlash.color().copy(alpha = (l * l * Cfg.screenBright).coerceIn(0f, 1f)))
    }
}
